<template>
<div class="row">
    <div class="col-sm-12 cell" @click="addClick('one')" v-html="divData[dynamicIndex].one">
    </div>
</div>
</template>

<script>
export default {
    
    methods: {
        
    }
}
</script>

<style>

</style>
