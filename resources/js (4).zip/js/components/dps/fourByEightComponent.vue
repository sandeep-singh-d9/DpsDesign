<template>
    <div  class="row">
        <div class="col-sm-4 cell" v-html="divData[dynamicIndex].seven" @click="addClick('seven')"></div>
        <div class="col-sm-8 cell" v-html="divData[dynamicIndex].eight" @click="addClick('eight')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
