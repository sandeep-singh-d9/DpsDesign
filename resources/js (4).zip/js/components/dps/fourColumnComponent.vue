<template>
    <div  class="row">
        <div class="col-sm-3 cell" v-html="divData[dynamicIndex].eleven" @click="addClick('eleven')"></div>
        <div class="col-sm-3 cell" v-html="divData[dynamicIndex].twelve" @click="addClick('twelve')"></div>
        <div class="col-sm-3 cell" v-html="divData[dynamicIndex].thirteen" @click="addClick('thirteen')"></div>
        <div class="col-sm-3 cell" v-html="divData[dynamicIndex].fourteen" @click="addClick('fourteen')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
