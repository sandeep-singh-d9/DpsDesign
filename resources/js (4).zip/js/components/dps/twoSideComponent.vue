<template>
  <div class="row">
    <div class="col-sm-6 cell">
      <div class="icon_top_inner">
       <i class="fas fa-plus-circle" data-toggle="modal" data-target="#exampleModal" @click="addClick('two')"></i>
      </div>
      <div v-html="divData[dynamicIndex].two"></div>
    </div>
    <!-- <div class="col-sm-6 cell" v-html="divData[dynamicIndex].three" @click="addClick('three')"></div> -->
    <div class="col-sm-6 cell">
      <div class="icon_top_inner">
        <i class="fas fa-plus-circle" data-toggle="modal" data-target="#exampleModal" @click="addClick('three')"></i>
      </div>
      <div v-html="divData[dynamicIndex].three"></div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>
