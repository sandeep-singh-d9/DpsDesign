<template>
    <div  class="row">
        <div class="col-sm-8 cell" v-html="divData[dynamicIndex].nine" @click="addClick('nine')"></div>
        <div class="col-sm-4 cell" v-html="divData[dynamicIndex].ten" @click="addClick('ten')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
