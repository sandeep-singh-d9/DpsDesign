<template>
    <div  class="row">
        <div class="col-sm-3 cell" v-html="divData[dynamicIndex].fifteen" @click="addClick('fifteen')"></div>
        <div class="col-sm-9 cell" v-html="divData[dynamicIndex].sixteen" @click="addClick('sixteen')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
