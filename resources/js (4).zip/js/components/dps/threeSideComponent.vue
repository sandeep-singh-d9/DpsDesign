<template>
    <div class="row">
        <div class="col-sm-4 cell" v-html="divData[dynamicIndex].four" @click="addClick('four')"></div>
        <div class="col-sm-4 cell" v-html="divData[dynamicIndex].five" @click="addClick('five')"></div>
        <div class="col-sm-4 cell" v-html="divData[dynamicIndex].six" @click="addClick('six')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
