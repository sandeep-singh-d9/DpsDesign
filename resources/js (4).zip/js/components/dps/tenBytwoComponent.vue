<template>
    <div class="row">
        <div class="col-sm-10 cell" v-html="divData[dynamicIndex].twentyone" @click="addClick('twentyone')"></div>
        <div class="col-sm-2 cell" v-html="divData[dynamicIndex].twentytwo" @click="addClick('twentytwo')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
