<template>
    <div class="row">
        <div class="col-sm-2 cell" v-html="divData[dynamicIndex].nineteen" @click="addClick('nineteen')"></div>
        <div class="col-sm-10 cell" v-html="divData[dynamicIndex].tweenteen" @click="addClick('tweenteen')"></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
